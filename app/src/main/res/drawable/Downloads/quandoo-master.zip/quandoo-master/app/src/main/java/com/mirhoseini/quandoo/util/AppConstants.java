package com.mirhoseini.quandoo.util;

/**
 * Created by Mohsen on 24/10/2016.
 */

public class AppConstants extends Constants {

    public static final int RECYCLER_VIEW_ITEM_SPACE = 48;

    public static final int CLEAR_TIME_INTERVAL = 10 * 60 * 1000; // 10 min

}
