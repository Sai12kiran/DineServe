package com.example.bluetoothchat;

import org.junit.Test;

import static org.junit.Assert.*;

public class LoginActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void fromHtml() {
    }

    @Test
    public void validate() {
    }
}