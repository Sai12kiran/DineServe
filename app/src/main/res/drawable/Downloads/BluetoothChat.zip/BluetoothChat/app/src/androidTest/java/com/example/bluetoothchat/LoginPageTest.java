package com.example.bluetoothchat;

import org.junit.Test;

import static org.junit.Assert.*;

public class LoginPageTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onUpgrade() {
    }

    @Test
    public void addUser() {
    }

    @Test
    public void authenticate() {
    }

    @Test
    public void isEmailExists() {
    }
}