package com.mirhoseini.quandoo;

/**
 * Created by Mohsen on 24/10/2016.
 */

public class QuandooApplicationImpl extends QuandooApplication {

    @Override
    public void initApplication() {
        // Crash report services can be initialized here for release version
    }

}
