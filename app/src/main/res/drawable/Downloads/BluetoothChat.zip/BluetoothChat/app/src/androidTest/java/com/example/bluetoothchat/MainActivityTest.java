package com.example.bluetoothchat;

import org.junit.Test;

import static org.junit.Assert.*;

public class MainActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onActivityResult() {
    }

    @Test
    public void onStart() {
    }

    @Test
    public void onResume() {
    }

    @Test
    public void onDestroy() {
    }
}